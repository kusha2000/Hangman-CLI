import java.util.Scanner;
import java.util.Random;
public class Hangman{
	Scanner sc=new Scanner(System.in);
	int ran;
	String choice;
	int choiceInt;
	String word;
	int wordCount;
	String letter;
	int count=1;
	int wrongCount;
	boolean wrongcheck;
	public static void main(String[] args) {
		Hangman hm=new Hangman();
		/*hm.wrongone();
		hm.wrongtwo();
		hm.wrongthree();
		hm.wrongfour();
		hm.wrongfive();
		hm.wrongsix();
		hm.correct();*/
		hm.menu();
	}
	public void play(){
		String[] words={"lucky","matrix","oxygen","icebox","zombie","jockey"};
		Random random=new Random();
		ran=random.nextInt(5);
		System.out.println("Random number is:"+ran+" Word is:"+words[ran]);
		word=words[ran];
		wordCount=word.length();
		System.out.println("Word Count:"+wordCount);
		for(int i=1;i<=wordCount;i++){
			System.out.print(" __ ");
		}
		System.out.println();
		System.out.println();
		System.out.println("a  b  c  d  e  f  g  h  i  j  k  l  m");
		System.out.println("n  o  p  q  r  s  t  u  v  w  x  y  z");
		System.out.println();
		while(count<7){
			wrongcheck=false;
			getLetters();
			for(int i=0;i<wordCount;i++){
				if(word.charAt(i)==letter.charAt(0)){
					//boolean letter+(i)=true;
					System.out.println(letter+" Found");
					count=count-1;
					wrongcheck=true;
					
				}else{

					System.out.println(letter+" Not Found");
					
				}
			}
			count=count+1;
			if(wrongcheck==false){
				wrongCount=wrongCount+1;
				switch(wrongCount){
					case 1:wrongone();break;
					case 2:wrongtwo();break;
					case 3:wrongthree();break;
					case 4:wrongfour();break;
					case 5:wrongfive();break;
					case 6:wrongsix();break;
			}
			}
		}

		
		
	}
	public void getLetters(){
		while(true){
			System.out.print("Plese enter a letter(a-z):");
			letter=sc.next();
			if(letter.length()==1 && (letter.matches("^[a-zA-Z]*$"))){
				break;
			}else{
				System.out.println("Plese enter only one letter(a-z):");
			}
		}
	}
	public void wrongone(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|		     |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	    \\=/         ");
		System.out.println("	|	                     ");
		System.out.println("	|	                     ");
		System.out.println("	|	                     ");
		System.out.println("	|	                     ");
		System.out.println("	|	                     ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|                        ");
		System.out.println("________|______________________________  ");
		
	}
	public void wrongtwo(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|		     |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	  _ \\=/ _        ");
		System.out.println("	|	          |     |         ");
		System.out.println("	|	          |	|   ");
		System.out.println("	|	          |	|    ");
		System.out.println("	|	          |	|     ");
		System.out.println("	|	          \\_ _ _/      ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|                        ");
		System.out.println("________|______________________________  ");
		
	}
	public void wrongthree(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|		     |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	  _ \\=/ _        ");
		System.out.println("	|	        /       |          ");
		System.out.println("	|	       / /|	|  ");
		System.out.println("	|	      | | |	|     ");
		System.out.println("	|	     | |  |	|    ");
		System.out.println("	|	     #    \\_ _ _/     ");
		System.out.println("	|	 	                   ");
		System.out.println("	|	 	                   ");
		System.out.println("	|	 	                   ");
		System.out.println("	|	 	                   ");
		System.out.println("	|	 	                   ");
		System.out.println("	|                          ");
		System.out.println("________|______________________________  ");
		
	}
	public void wrongfour(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|		     |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	  _ \\=/ _        ");
		System.out.println("	|	        /         \\     ");
		System.out.println("	|	       / /|	|\\ \\   ");
		System.out.println("	|	      | | |	| | |    ");
		System.out.println("	|	     | |  |	|  | |   ");
		System.out.println("	|	     #    \\_ _ _/    #  ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|	 	                 ");
		System.out.println("	|                        ");
		System.out.println("________|______________________________  ");
		
	}
	public void wrongfive(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|		     |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	  _ \\=/ _        ");
		System.out.println("	|	        /         \\     ");
		System.out.println("	|	       / /|	|\\ \\   ");
		System.out.println("	|	      | | |	| | |    ");
		System.out.println("	|	     | |  |	|  | |   ");
		System.out.println("	|	     #    \\_ _ _/    #  ");
		System.out.println("	|	 	  |  |         ");
		System.out.println("	|	 	  |  |          ");
		System.out.println("	|	 	  |  |         ");
		System.out.println("	|	 	  |  |          ");
		System.out.println("	|	 	 /__]       ");
		System.out.println("	|                        ");
		System.out.println("________|______________________________  ");
		
	}
	public void wrongsix(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|		     |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	  _ \\=/ _        ");
		System.out.println("	|	        /         \\     ");
		System.out.println("	|	       / /|	|\\ \\   ");
		System.out.println("	|	      | | |	| | |    ");
		System.out.println("	|	     | |  |	|  | |   ");
		System.out.println("	|	     #    \\_ _ _/    #  ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	 /__]_[__\\       ");
		System.out.println("	|                        ");
		System.out.println("________|______________________________  ");
		
	}
	public void correct(){
		
		System.out.println("	______________________________   ");
		System.out.println("	|                        ");
		System.out.println("	|		     		     ");
		System.out.println("	|		               ");
		System.out.println("	|		                ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	           |0 0|         ");
		System.out.println("	|	 	  _ \\=/ _        ");
		System.out.println("	|	        /         \\     ");
		System.out.println("	|	       / /|	|\\ \\   ");
		System.out.println("	|	      | | |	| | |    ");
		System.out.println("	|	     | |  |	|  | |   ");
		System.out.println("	|	     #    \\_ _ _/    #  ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("________|________________/__]_[__\\__________  ");
		
	}
	public void menu(){
		System.out.println("\t|+-------------+|");
		System.out.println("\t|+---Hangman---+|");
		System.out.println("\t|+-------------+|");
		while(true){
			System.out.println();
			System.out.println("+-----------------------+");
			System.out.println("|       Main Menu       |");
			System.out.println("+-----------------------+");
			System.out.println("| 1.To Play Hangman     |");
			System.out.println("| 2.How to Play Nim     |");
			System.out.println("| 3.Exit                |");
			System.out.println("+-----------------------+");
			while(true){
				try{
					System.out.print("Enter your choice(1-3):");
				    choice=sc.next();
					choiceInt=Integer.parseInt(choice);
					if(choiceInt==1){
						Hangman hm=new Hangman();
						hm.play();
						System.out.println("Still Under Construction");
						System.out.print("Press any key to goto menu:");
						String exit=sc.next();
						break;
					}else if(choiceInt==2){
						System.out.println("Still Under Construction");
						System.out.print("Press any key to goto menu:");
						String exit=sc.next();
						break;
					}else if(choiceInt==3){
						System.exit(0);
					}else{
						System.out.println("Please enter correct value(1-3)");
					}
			}catch(Exception e){
				System.out.println("Please enter correct integer value(1-3)");
			}
			}	
			
			



		}


	}
}

/*
	System.out.println("")			______________________
	System.out.println("")			|			 |			
									|		 	 |
									|		     |
									|		    /~\
									|	       |0 0|
									|	 	  _ \=/ _
									|	    /         \
									|	   / /|	    |\ \
									|	  |	| |	    | | |
									|	 | |  |	    |  | |
									|	 # 	  \_ _ _/    #
									|	 	  |  |  |
									|	 	  |  |  |
									|	 	  |  |  |
									|	 	  |  |  |
									|	 	 /__]_[__\ 
									|
								____|____

System.out.println("	______________________   ");
		System.out.println("	|			 |		     ");
		System.out.println("	|		     |           ");
		System.out.println("	|		     |           ");
		System.out.println("	|		    /~\\         ");
		System.out.println("	|	       |0 0|         ");
		System.out.println("	|	 	  _\\=/ _        ");
		System.out.println("	|	    /         \\     ");
		System.out.println("	|	   / /|	    |\\ \\   ");
		System.out.println("	|	  |	| |	    | | |    ");
		System.out.println("	|	 | |  |	    |  | |   ");
		System.out.println("	|	 # 	  \\_ _ _/    #  ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	  |  |  |        ");
		System.out.println("	|	 	 /__]_[__\\       ");
		System.out.println("	|                        ");
		System.out.println("____|____                    ");
*/



